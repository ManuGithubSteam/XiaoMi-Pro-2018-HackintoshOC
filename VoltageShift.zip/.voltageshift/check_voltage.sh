#!/bin/bash

cd ~/.voltageshift

while [ 1 ]
do

echo ""sleep.... 
sleep 300

# check voltage
sudo ./voltageshift_unsigned info | grep "CPU voltage offset" | grep 107
RES=$(echo $?)

if [ $RES = 1 ];then
echo "set voltage saving again.."

# Setup voltage
sudo ./voltageshift_unsigned offset -107 -73 -107 0 0 0 25.5 999999 25.5 999999 60

else

echo "Voltage is set. Nothing to do"

fi

sudo ./voltageshift_unsigned powerlimit | grep PL1 | grep 25W
RESP=$(echo $?)

if [ $RESP = 1 ];then
echo "set power saving again.."

# Setup power
sudo ./voltageshift_unsigned powerlimit 25.5 999999 25.5 999999

else

echo "Power is set. Nothing to do"

fi

done
